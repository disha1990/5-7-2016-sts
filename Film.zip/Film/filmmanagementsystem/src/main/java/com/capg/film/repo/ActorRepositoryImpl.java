package com.capg.film.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.bean.Actor;
import com.capgemini.bean.Category;
import com.capgemini.bean.Film;

public class ActorRepositoryImpl implements ActorRepo {
	private EntityManager em;

	public ActorRepositoryImpl(EntityManager em) {
		this.em = em;
	}

	public Actor save(Actor actor) {
		em.persist(actor);
		return actor;
	}

	public List<Actor> searchByName(String firstName, String lastName) {

		return null;
	}

	public List<Actor> searchByAge(byte age) {

		return null;
	}

	public Actor modifyActor(int id,Actor actor) {

		Actor savedActor =em.find(Actor.class, id);
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		
		em.persist(savedActor);
		return savedActor;
	}

	public Boolean deleteActor(String name) {

		return null;
	}

}
