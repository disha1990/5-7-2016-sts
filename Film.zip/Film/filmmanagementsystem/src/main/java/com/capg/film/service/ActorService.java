package com.capg.film.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.bean.Actor;



public interface ActorService {

	public Actor addActor(HashMap mapActor);

	public List<Actor> searchByName(String firstName, String lastName);

	public Actor modifyActor(int id,Actor actor);

	public String deleteActor(String name);

}

