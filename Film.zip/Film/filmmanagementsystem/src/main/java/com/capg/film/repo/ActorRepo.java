package com.capg.film.repo;

import java.util.List;

import com.capgemini.bean.Actor;
import com.capgemini.bean.Film;

public interface ActorRepo {
	public Actor save(Actor actor);

	public List<Actor> searchByName(String firstName, String lastName);

	public List<Actor> searchByAge(byte age);

	public Actor modifyActor(int id, Actor actor);

	public Boolean deleteActor(String name);
}
