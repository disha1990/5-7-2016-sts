package com.capg.film.service;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.capgemini.bean.Film;
public interface FilmService {

	public String addFilm(HashMap map);

	public List<Film> searchByTitle(String title);

	public List<Film> searchByLanguage(String language);

	public List<Film> searchByReleaseYear(int year);

	public List<Film> searchByCategory(String category);

	public List<Film> searchByActor(String first);

	public List<Film> searchByRating(byte rating);

	public String modifyFilm(HashMap map);

	public String deleteFilm(String title);

}

